const fs = require('fs');
const chalk = require('chalk');

//~~~~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~~~~\\

global.owner = ['6281364573062', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0']
global.packname = 'PallAssisten'
global.PallAssisten = 'WhatsApp-bot'
global.author = 'Fahmen'
global.fazz = 'PallAssisten'
global.botname = 'PallAssisten'
global.listprefix = ['+','!']
global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.tempatDB = 'database.json'
global.thumb = fs.readFileSync('./src/media/faz.png'); // 
global.pairing_code = true

global.fake = {
	anonim: 'https://telegra.ph/file/95670d63378f7f4210f03.png',
	thumbnailUrl: 'https://drive.usercontent.google.com/download?id=1-3LW80t18wDldXom1Mu1Ta78wD0T2m7u&authuser=0',
	thumbnail: fs.readFileSync('./src/media/faz.png'),
	docs: fs.readFileSync('./src/media/fake.pdf'),
	listfakedocs: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/pdf'],
}

global.my = {
	yt: 'https://donatesuport.rf.gd/',
	gh: 'https://donatesuport.rf.gd/',
	gc: 'https://chat.whatsapp.com/DTWMB8ttzVt29QMRiVwZCg',
	ch: '0029Vaz7yJFHVvTYroi7o227@newsletter',
}

global.limit = {
	free: 15,
	premium: 999999999999999,
	vip: 'VIP'
}

global.uang = {
	free: 5000,
	premium: 0,
	vip: 0
}

global.mess = {
	key0: 'Apikey mu telah habis silahkan kunjungi\nhttps://my.hitori.pw',
	owner: 'Fitur Khusus Owner!',
	admin: 'Fitur Khusus Admin!',
	botAdmin: 'Bot Bukan Admin!',
	group: 'Gunakan Di Group! Tidak ada grub?\n\nKetik \`.gcbot\`',
	private: 'Gunakan Di Chat Pribadi!',
	prem: 'Untuk menggunakan fitur itu kamu harus upgrade menjadi user premium dulu!\n\n\`ketik .premium untuk info selanjutnya\`',
	wait: 'Loading... . .',
	error: 'Error! 😭',
	done: 'Done'
}

global.APIs = {
	hitori: 'https://my.hitori.pw/api',
}
global.APIKeys = {
	'https://my.hitori.pw/api': 'htrkey-awokawok',
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});